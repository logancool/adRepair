FT.manifest({
	"filename": "indexs$$ .html",
	"width": 300,
	"height": 250,
	"clickTagCount": 1,
	"hideBrowsers": ["ie8"],
	"videos": [{"name": "video1", "ref": "https://www.youtube.com/watch?v=yS9bZHthxY0"}]
});